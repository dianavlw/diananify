const express = require("express");
const authenticate = require("../middleware/authMiddleware"); // ✅ Import Middleware
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "your_jwt_secret"; // ✅ Make sure .env is loaded

// ✅ Register a User Route
router.post("/register", async (req, res) => {
    const { username, email, password } = req.body;

    try {
        console.log("🔹 Incoming Registration Request:", { username, email, password });

        // Check if email already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists" });
        }

        // Step 1: Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);
        console.log("🔹 Hashed Password:", hashedPassword);

        // Step 2: Save user with hashed password
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        res.status(201).json({ message: "User registered successfully", user: newUser });

    } catch (error) {
        console.error("❌ Registration Error:", error);
        res.status(500).json({ message: "Server error", error: error.message });
    }
});



// ✅ Login Route
// ✅ Login Route
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    try {
        console.log("🟢 Incoming Login Request:", { email, password });

        // Check if user exists
        const user = await User.findOne({ email });

        if (!user) {
            console.log("❌ User not found in database");
            return res.status(401).json({ message: "Invalid credentials" });
        }

        console.log("🔍 Checking password:");
        console.log("Entered Password:", password);
        console.log("Stored Hashed Password:", user.password);

        // Compare the entered password with the stored hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        console.log("Password Match?", isMatch);

        if (!isMatch) {
            console.log("❌ Password does not match!");
            return res.status(401).json({ message: "Invalid credentials" });
        }

        // ✅ Generate JWT Token
        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        console.log("✅ Login Successful! Token:", token);

        res.json({ message: "Login successful", token });

    } catch (error) {
        console.error("❌ Login Error:", error);
        res.status(500).json({ message: "Server error" });
    }
});


// ✅ Protected Route: Get User Profile (Only Logged-in Users Can Access)
router.get("/profile", authenticate, async (req, res) => {
    res.json({ message: `Welcome ${req.user.userId}, this is your profile.` });
});

module.exports = router; // ✅ Correct Placement (Only One Export)
