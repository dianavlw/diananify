const express = require("express");
const jwt = require("jsonwebtoken");
const Product = require("../models/Product");

const router = express.Router();

// Middleware to verify token
const authenticate = (req, res, next) => {
  const token = req.header("Authorization");
  if (!token) return res.status(401).json({ message: "Access denied" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(400).json({ message: "Invalid token" });
  }
};

// ✅ Add a Product (Protected Route)
router.post("/", authenticate, async (req, res) => {
  try {
    const { name, price, description } = req.body;
    const product = new Product({ name, price, description, user: req.user.id });
    await product.save();
    res.status(201).json(product);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ✅ Get All Products
router.get("/", async (req, res) => {
  const products = await Product.find().populate("user", "username");
  res.json(products);
});

module.exports = router;
